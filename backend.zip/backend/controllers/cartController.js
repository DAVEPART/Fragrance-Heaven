import userModel from "../models/userModel.js";

// add products to user cart
const addToCart = async (req, res) => {
  try {
    const { userId, itemId, size } = req.body;

    const userData = await userModel.findById(userId);
    let cartData = await userData.cartData;

    if (cartData[itemId]) {
      if (cartData[itemId][size]) {
        cartData[itemId][size] += 1;
      } else {
        cartData[itemId][size] = 1;
      }
    } else {
      cartData[itemId] = {};
      cartData[itemId][size] = 1;
    }

    await userModel.findByIdAndUpdate(userId, { cartData });

    res.json({ success: true, message: "Added To Cart" });
  } catch (error) {
    console.log(error);
    res.json({ success: false, message: error.message });
  }
};

// update user cart
const updateCart = async (req, res) => {
  try {
    const { userId, itemId, size, quantity } = req.body;

    const userData = await userModel.findById(userId);
    let cartData = await userData.cartData;
    console.log("cartData: ", cartData);

    console.log("quantity: ", quantity);
    cartData[itemId][size] = quantity;

    await userModel.findByIdAndUpdate(userId, { cartData });
    res.json({ success: true, message: "Cart Updated" });
  } catch (error) {
    console.log(error);
    res.json({ success: false, message: error.message });
  }
};

//
const deleteCart = async (req, res) => {
  try {
    // const { userId, itemId, size } = req.body;
    console.log("req.param: ", req.params);
    const itemId = req.params.id;
    console.log("itemId: ", itemId);
    const userId = req.params.user_id;
    console.log("userId: ", userId);
    // if (!userId || !itemId || !size) {
    //     return res.status(400).json({ success: false, message: "Missing userId, itemId, or size" });
    // }

    const userData = await userModel.findById(userId);
    console.log("userData: ", userData);
    if (!userData) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    const updatedUser = await userModel.findById(userId);
    console.log('Object.keys(updatedUser.cartData[itemId]).length === 0: ', Object.keys(updatedUser.cartData[itemId]).length === 0)
    if (
      updatedUser.cartData[itemId] 
    ) {
      const updateResult = await userModel.updateOne(
        { _id: userId },
        { $unset: { [`cartData.${itemId}`]: "" } }
      );
      console.log("updateResult: ", updateResult);
    }

    res.json({ success: true, message: "Cart item deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: error.message });
  }
};

// get user cart data
const getUserCart = async (req, res) => {
  try {
    const { userId } = req.body;

    const userData = await userModel.findById(userId);
    let cartData = await userData.cartData;

    res.json({ success: true, cartData });
  } catch (error) {
    console.log(error);
    res.json({ success: false, message: error.message });
  }
};

export { addToCart, updateCart, getUserCart, deleteCart };
