import Contact from '../models/contactModel.js';

export const createContact = async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
      return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    const contact = new Contact({ name, email, subject, message });
    await contact.save();

    res.status(201).json({ success: true, message: 'Message sent successfully!' });
  } catch (error) {
    console.error('Error creating contact:', error);
    res.status(500).json({ success: false, message: 'Server Error. Please try again later.' });
  }
};

export const getAllContacts = async (req, res) => {
  try {
    const submissions = await Contact.find().sort({ createdAt: -1 }); // latest first
    res.status(200).json({ success: true, submissions });
  } catch (error) {
    console.error('Error fetching contacts:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch submissions' });
  }
};
