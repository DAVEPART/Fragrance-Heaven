import express from 'express';
import { createContact, getAllContacts } from '../controllers/contactController.js';

const router = express.Router();

// POST /api/contact/contact
router.post('/contact', createContact);

// ✅ NEW: GET /api/contact/submissions
router.get('/submissions', getAllContacts);

export default router;
