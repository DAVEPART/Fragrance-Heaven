import express from 'express'
import { addToCart, getUserCart, updateCart, deleteCart } from '../controllers/cartController.js'
import authUser from '../middleware/auth.js'

const cartRouter = express.Router()

cartRouter.post('/get',authUser, getUserCart)
cartRouter.post('/add',authUser, addToCart)
cartRouter.post('/update',authUser, updateCart)
cartRouter.delete('/delete/:user_id/:id',authUser, deleteCart)

export default cartRouter